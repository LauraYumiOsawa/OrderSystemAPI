using Microsoft.EntityFrameworkCore;
using OrderSystemAPI.Data;

namespace OrderSystemAPI;

internal class Program
{
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // sqlServer?
        builder.Services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer("Server=localhost;Database=TalTal;Trusted_Connection=True;TrustServerCertificate=True;"));

        builder.Services.AddControllers();

        var app = builder.Build();

        app.MapControllers();

        using (var scope = app.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.EnsureCreated();
        }

        app.Run();       
    }
}